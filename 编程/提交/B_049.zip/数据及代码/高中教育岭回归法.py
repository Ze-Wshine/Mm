import pandas as pd
import numpy as np

from sklearn.linear_model import Ridge
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler 

df = pd.read_excel(r'数据集\第二题整合数据.xlsx')


# 选择自变量
X = df[['总户数/万户', '户均人口/人/户', '年末常驻总人口/万人', '出生率/%', '死亡率/%', '人口自然增长率/%', '城镇化率/%']]


# 选择因变量
y = df['高中教育在校生/万人']

# 标准化自变量
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
'''
# 检验标准化是否成功

# 计算每个特征的均值和标准差

means = pd.DataFrame(X_scaled, columns=X.columns).mean()
std_devs = pd.DataFrame(X_scaled, columns=X.columns).std()
print("均值：\n", means)
print("标准差：\n", std_devs)

# 经检验，均值接近0，标准差接近1，标准化成功。
'''
# 构建岭回归模型并交叉验证

# 定义 alpha 范围
param_grid = {'alpha': np.logspace(-3, 3, 100)}

# 构建岭回归模型并网格搜索交叉验证
ridge = Ridge()
grid_search = GridSearchCV(ridge, param_grid, cv=5, scoring='r2')
grid_search.fit(X_scaled, y)

# 输出最佳 alpha 和模型
print(f"最佳 alpha 值: {grid_search.best_params_['alpha']}")

best_model = grid_search.best_estimator_

# 模型评估
coefficients = best_model.coef_
print("回归系数:", coefficients)

r2 = best_model.score(X_scaled, y)
print(f"模型 R² 分数: {r2}")
